import { MCEPlugin } from '../providers/mce.provider';


export const PROVIDERS = [
    MCEPlugin 
];

